<?php
function function1(){
    //$activities=fopen("settings/settings.xml", "r");
    $xml = simplexml_load_file("settings/settings.xml");
    //print_r($xml);
    $array = $xml->frontpage->section;
    for($i = 0; $i < count($array); $i++){
     if ($array[$i]['visibility'] == "1" ){
        echo "<div class='row'>".$array[$i]["id"]."<input type='checkbox' name='a' value='1' visibility = '1'  id=".$array[$i]["id"]. " checked></div>";}
        else if ($array[$i]['visibility'] == "0"){
        echo "<div class='row'>".$array[$i]["id"]."<input type='checkbox' name='b'  visibility = '0' id=".$array[$i]["id"]. "></div>";
}
}
}
?>