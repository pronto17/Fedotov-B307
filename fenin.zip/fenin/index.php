<!DOCTYPE html>
<html>
<head>
    <title>02.09.2021</title>
</head>
<body>
<?php
    require 'func.php';
    echo function1();
?>
</body>
</html>